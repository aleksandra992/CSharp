﻿namespace _9.StudentGroups
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    public class StartingPoint
    {
        public static void Main()
        {
            TestingStudents.TestStudents();


        }
    }
}
